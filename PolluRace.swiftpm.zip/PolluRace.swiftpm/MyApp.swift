import SwiftUI

@main
struct MyApp: App {
    @StateObject var myGame = GameData()

    // Register AppDelegate to control orientation
    @UIApplicationDelegateAdaptor(AppDelegate.self) var appDelegate

    var body: some Scene {
        WindowGroup {
            MainMenu()
                .environmentObject(myGame)
                .onAppear {
                    setLandscapeOrientation()
                }
        }
    }
}

// AppDelegate to Lock Orientation to Landscape Only
class AppDelegate: NSObject, UIApplicationDelegate {
    static var orientationLock = UIInterfaceOrientationMask.landscape

    func application(_ application: UIApplication, supportedInterfaceOrientationsFor window: UIWindow?) -> UIInterfaceOrientationMask {
        return AppDelegate.orientationLock
    }
}

// Function to Set Landscape Orientation
@MainActor func setLandscapeOrientation() {
    let value = UIInterfaceOrientation.landscapeRight.rawValue
    UIDevice.current.setValue(value, forKey: "orientation")
    UINavigationController.attemptRotationToDeviceOrientation()
}
