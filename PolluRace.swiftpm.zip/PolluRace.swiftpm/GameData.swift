//
//  GameData.swift
//  PolluRace
//
//  Created by Purawit Lattiprasat on 18/2/2568 BE.
//
import Foundation

class GameData : ObservableObject {
    @Published var carNameSelected : String
    @Published var carImageSelected : String
    @Published var gameStatus : String
    @Published var distanceData : String
    
    init(){
        self.carNameSelected = ""
        self.carImageSelected = ""
        self.gameStatus = ""
        self.distanceData = ""
    }
    func resetGame(){
        self.carNameSelected = ""
        self.carImageSelected = ""
        self.gameStatus = ""
        self.distanceData = ""
    }
    func calculateCO2(distance: String, fuelType: String) -> Double {
        let emissionFactors: [String: Double] = [
            "Gasoline": 2310.0,
            "Diesel": 2680.0,
        ]
        let distanceDouble = Double(distance)!
        if let emissionFactor = emissionFactors[fuelType] {
            if fuelType == "Gasoline" {
                let fuelConsumption = 0.10
                return (distanceDouble * fuelConsumption * emissionFactor)/1000
            }
            else if fuelType == "Diesel"{
                let fuelConsumption = 0.6
                return (distanceDouble * fuelConsumption * emissionFactor)/1000
            }
        }
        return 0.0
    }
    
    func calculateNOx(distance: String, fuelType: String) -> Double {
        let noxFactors: [String: Double] = [
            "Gasoline": 0.1,  // 0.05 - 0.2 g/km
            "Diesel": 1,    // Older diesel cars 0.5 - 1.5 g/km
        ]
        let distanceDouble = Double(distance)!
        if let noxFactor = noxFactors[fuelType] {
            return (distanceDouble * noxFactor)
        }
        return 0.0
    }
    
    func calculateEV(distance: String) -> Double {
        let distanceDouble = Double(distance)!
        let energyConsumption:Double = 0.2
        let emissonFactors:Double  = 370 //estimate from USA
        return (distanceDouble*energyConsumption*emissonFactors)/1000
    }
}
