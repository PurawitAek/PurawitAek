
import SwiftUI
struct CarView: View {
    var carName : String
    var carType : String
    var carSpeed: String
    var carImage : String
    var horsePower : String

    @EnvironmentObject var myGame: GameData

    var body: some View {
        ZStack{
            VStack{
                Image(uiImage: UIImage(named:carImage)!)
                    .padding(.trailing, 40.0)
                    .scaledToFill()
                    .aspectRatio(contentMode: .fit)
                VStack{
                    Text(carName)
                        .font(.system(size: 20, weight: .bold, design: .monospaced))
                        .fontWeight(.bold)
                        .multilineTextAlignment(.leading)
                    Text("Type: \(carType)")
                        .font(.title3)
                        .fontWeight(.light)
                        .multilineTextAlignment(.leading)
                    
                    Text("Max speed: \(carSpeed)")
                        .font(.headline)
                        .fontWeight(.medium)
                        .multilineTextAlignment(.leading)
                    
                    Text("Horse power: \(horsePower)")
                        .font(.headline)
                        .fontWeight(.medium)
                        .multilineTextAlignment(.leading)
                }
                
            }
            .frame(width: 230, height: 220)
            .background(Color(hue: 1.0, saturation: 0.0, brightness: 0.876))
            .cornerRadius(10)
            VStack{
                Button(action:{
                    myGame.carNameSelected = carName
                    myGame.carImageSelected = carImage
                }){
                    Text("SELECT")
                        .frame(width:120,height:40)
                        .font(.title)
                        .fontWeight(.bold)
                        .background(Color.green)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                }
            }
            .offset(y:110)
        }
    }
    
}
struct CarView_Previews: PreviewProvider {
    static var previews: some View {
        CarView(carName: "Toyada Prize 2004", carType: "Petrol Car", carSpeed: "120km/hr", carImage: "NormalCar", horsePower: "300HP")
    }
}

