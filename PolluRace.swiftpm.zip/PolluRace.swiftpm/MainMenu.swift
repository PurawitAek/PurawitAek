import SwiftUI
import AVFoundation

struct MainMenu: View {
    @State private var carOffset: CGFloat = 0 // Offset for car movement
    @State private var buttonOpacity: Double = 1.0
    @EnvironmentObject var myGame: GameData
    @State private var isStart: Bool = false
//    @State private var audioPlayer: AVAudioPlayer? // Keep audio player alive

    var body: some View {
        NavigationStack {
            ZStack {
                // Background
                Image("MainPageBG")
                    .resizable()
                    .scaledToFill()
                    .edgesIgnoringSafeArea(.all)
                
                // Moving Car
                Image("RedCarFirst")
                    .position(x: 140 + carOffset, y: 310)
                    .animation(.easeInOut(duration: 2), value: carOffset)
                
                // NavigationLink triggered by gameStatus state
                NavigationLink(destination: SelectCar(myGame: _myGame), isActive: $isStart) {
                    EmptyView()
                }
                
                // Start Game Button
                Button(action: {
                    carOffset += 800 // Move car to the right
                    myGame.gameStatus = "Select"
                    
                    withAnimation(.easeOut(duration: 1)) {
                        buttonOpacity = 0
                    }
                    
//                    playSound()
                    
                    DispatchQueue.main.asyncAfter(deadline: .now() + 2) { // Delay navigation
                        isStart = true
                    }
                }) {
                    Text("START GAME")
                        .font(.system(size: 24, weight: .bold, design: .monospaced))
                        .padding()
                        .frame(width: 200, height: 60)
                        .background(Color.red)
                        .foregroundColor(.white)
                        .cornerRadius(15)
                }
                .opacity(buttonOpacity)
                .offset(y: 75)
            }
            .onAppear {
                // Reset game state when returning to the menu from backbutton
                if myGame.gameStatus == "" || myGame.gameStatus == "Main" {
                    carOffset = 0
                    buttonOpacity = 1.0
                    isStart = false
                    myGame.carNameSelected = ""
                    myGame.carImageSelected = ""
                }
            }
            .navigationBarBackButtonHidden()
        }
    }
    // There is some error in using sound TT
    // Function to Play Sound
//    func playSound() {
//        if let path = Bundle.main.path(forResource: "pop-bottle", ofType: "mp3") {
//            let url = URL(fileURLWithPath: path)
//            do {
//                audioPlayer = try AVAudioPlayer(contentsOf: url)
//                audioPlayer?.volume = 1.0
//                audioPlayer?.play()
//            } catch {
//                print("Error playing sound: \(error.localizedDescription)")
//            }
//        } else {
//            print("Sound file 'pop-bottle.mp3' not found in bundle")
//        }
//    }
}

struct MainMenu_Previews: PreviewProvider {
    static var previews: some View {
        MainMenu()
            .environmentObject(GameData()) // Ensure GameData is provided
    }
}
