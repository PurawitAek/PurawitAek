import SwiftUI

struct EndScene: View {
    @EnvironmentObject var myGame: GameData
    @State private var isMainMenu = false
    @State private var showHomebutton = false
    @State private var showPhase = 0  // 0: Win message, 1: Stats, 2: Final message
    
    var body: some View {
        NavigationStack{
            ZStack {
                if myGame.carImageSelected == "NormalCar"{
                    Image("NormalEndBG")
                        .resizable()
                        .scaledToFill()
                    .edgesIgnoringSafeArea(.all)}
                else if myGame.carImageSelected == "SportCar"{
                    Image("SportEndBG")
                        .resizable()
                        .scaledToFill()
                    .edgesIgnoringSafeArea(.all)}
                else if myGame.carImageSelected == "ElectricCar"{
                    Image("ElectricEndBG")
                        .resizable()
                        .scaledToFill()
                    .edgesIgnoringSafeArea(.all)}
                VStack {
                    switch showPhase {
                    case 0:
                        // win message
                        Text("You Win!")
                            .font(.system(size: 48, weight: .bold))
                            .foregroundColor(.red)
                            .multilineTextAlignment(.center)
                            .shadow(color: .white, radius: 5)
                            .padding()
                            .background(
                                RoundedRectangle(cornerRadius: 10)
                                    .fill(Color.white.opacity(0.7))
                                    .padding(.horizontal, -20.0)
                            )
                            .transition(.opacity)
                            .onAppear {
                                Task {
                                    await delay(seconds: 3)
                                    withAnimation {
                                        showPhase = 1
                                    }
                                }
                            }
                        
                    case 1:
                        // Car stats message
                        getEndMessage(for: myGame.carImageSelected)
                            .padding(.horizontal, 50.0)
                            .transition(.opacity)
                            .onAppear {
                                Task {
                                    await delay(seconds: 15)
                                    withAnimation {
                                        showPhase = 2
                                        myGame.gameStatus = "End"
                                    }
                                }
                            }
                        
                    case 2:
                        // Final environmental message
                        VStack{
                            Text("To Every Driver")
                                .font(.system(size: 48, weight: .bold))
                                .fontWeight(.bold)
                                .foregroundColor(Color.black)
                                .multilineTextAlignment(.center)
                                .shadow(color:.white, radius: 5)
                                .padding()
                            Text("""
                         Every car journey impacts our planet - from the CO₂ and NOx emissions that warm our climate, to the air pollution affecting our health. But today, you've learned there are choices! Whether it's driving efficiently, choosing electric vehicles, or using eco-friendly transport, every decision counts.
                         
                         Just like in this race, your real-world driving choices can help create a cleaner, healthier Earth. 
                         
                         Would you like to try other car? Press home button at top right corner.
                         """)
                            .font(.system(size: 20, weight: .bold))
                            .frame(width: 700,height:250)
                            .foregroundColor(.white)
                            .multilineTextAlignment(.center)
                            .padding()
                            .background(
                                RoundedRectangle(cornerRadius: 10)
                                    .fill(Color.green.opacity(0.8))
                                    .padding(.all)
                            )
                            .transition(.opacity)
                        }
                        .onAppear {
                            withAnimation {
                                showHomebutton = true
                            }
                        }
                    default:
                        EmptyView()
                    }
                    
                
            }//end Vstack
            NavigationLink(destination:MainMenu(),isActive:$isMainMenu){
                EmptyView()}
                if showHomebutton{
                    Button(action:{
                        myGame.resetGame()
                        isMainMenu = true
                    }){
                        Image(systemName:"house.fill")
                            .frame(width: 40, height: 40)
                            .background(Color.gray.opacity(0.8))
                            .foregroundColor(.white)
                            .clipShape(Circle())
                            .position(x:UIScreen.main.bounds.width - 150, y: UIScreen.main.bounds.height - 350)
                    }
                }
            }
            
        }
        .navigationBarBackButtonHidden(true)
    }
    
    @ViewBuilder
    private func getEndMessage(for carType: String) -> some View {
        let message: String
        
        switch carType {
        case "NormalCar":
            message = """
            Car Stats:
            Speed: ⭐⭐
            Eco-Rating: ⭐⭐
            Fuel Consumption Rate: 10L/100km (Gasoline)
            Distance: \(myGame.distanceData) km
            ---------------------------------------------
            You cause our Earth a little bit gray
            
            CO₂ Released: \(myGame.calculateCO2(distance: myGame.distanceData, fuelType: "Gasoline")) kg 
            NOx Released: \(myGame.calculateNOx(distance: myGame.distanceData, fuelType: "Gasoline")) g
            
            The track's still looking not bad. High five for keeping things clean while having fun!
            ---------------------------------------------
            """
        case "SportCar":
            message = """
            Race Stats:
            Speed: ⭐⭐⭐
            Eco-Rating: ⭐
            Fuel Consumption Rate: 6L/100km (Diesel)
            Distance: \(myGame.distanceData) km
            ---------------------------------------------
            You just SMOKE the Earth!!
            
            CO₂ Released: \(myGame.calculateCO2(distance: myGame.distanceData, fuelType: "Diesel")) kg 
            NOx Released: \(myGame.calculateNOx(distance: myGame.distanceData, fuelType: "Diesel")) g 
            
            Your ride added extra smog to our sky. Those clouds are looking a bit red now!
            ---------------------------------------------
            """
        case "ElectricCar":
            message = """
            Race Stats:
            Speed: ⭐
            Eco-Rating: ⭐⭐⭐
            Energy Used: 0.2 kWh/km (Electric Vehicle)
            Distance: \(myGame.distanceData) km
            ---------------------------------------------
            Thanks for help the earth reduce the pollution from petrol
            
            CO₂ Released: \(myGame.calculateEV(distance:myGame.distanceData)) kg (Indirect CO2)
            NOx Released: 0g (Zero direct emissions - that's the EV advantage!)
            
            Nothing but clean air here!
            ---------------------------------------------
            """
        default:
            message = "Error: No car selected."
        }
        
        return Text(message)
            .font(.system(size: 20, weight: .bold))
            .foregroundColor(.white)
            .multilineTextAlignment(.leading)
            .shadow(color: .black, radius: 5)
            .padding()
            .background(
                RoundedRectangle(cornerRadius: 10)
                    .fill(Color.black.opacity(0.7))
                    .padding(.horizontal, -20.0)
            )
    }
    
    private func delay(seconds: Int) async {
        try? await Task.sleep(for: .seconds(seconds))
    }
}

struct EndScene_Previews: PreviewProvider {
    static var previews: some View {
        EndScene()
            .environmentObject(GameData())
    }
}
