import SwiftUI

struct GameView: View {
    @State private var inputDistance: String = ""
    @State private var bgOffset: CGFloat = 0
    @State private var carHorizonOffset: CGFloat = 0
    @State private var carVerticalOffset: CGFloat = 0
    @State private var buttonOpacity: Double = 1.0
    @State private var countNum: Int = 3
    @State private var showCountdown: Bool = false
    @State private var showIntroText: Bool = true
    @State private var isEnd: Bool = false
    @EnvironmentObject var myGame: GameData
    
    var body: some View {
        NavigationStack{
            ZStack {
                // Background Image
                Image("GameBG")
                    .resizable()
                    .scaledToFill()
                    .frame(width: UIScreen.main.bounds.width, alignment: .leading)
                    .offset(x: bgOffset)
                    .ignoresSafeArea()
                
                // Enter distance Intro
                if myGame.gameStatus == "Waiting" {
                    VStack {
                        Text("Enter distance to finish (km)")
                            .font(.system(size: 22, weight: .bold))
                            .foregroundColor(.yellow)
                            .shadow(color: .black, radius: 5)
                        
                        HStack {
                            TextField("e.g. 120", text: $inputDistance)
                                .keyboardType(.numberPad)
                                .textFieldStyle(RoundedBorderTextFieldStyle())
                                .padding()
                                .frame(width: 200)
                            
                            Button(action: {
                                if let _ = Int(inputDistance), !inputDistance.isEmpty {
                                    withAnimation {
                                        buttonOpacity = 0 // Fade out button
                                    }
                                    myGame.gameStatus = "Ready"
                                    myGame.distanceData = inputDistance
                                    showCountdown = true
                                }
                            }) {
                                Image(systemName: "chevron.right")
                                    .frame(width: 30, height: 30)
                                    .background(Color.gray.opacity(0.8))
                                    .foregroundColor(.white)
                                    .clipShape(Circle())
                            }
                        }
                    }
                    .frame(width: 300, height: 150)
                    .background(
                        RoundedRectangle(cornerRadius: 10)
                            .fill(Color.black.opacity(0.7))
                            .padding(.horizontal, -20.0)
                    )
                    .opacity(buttonOpacity) // fade out button
                }
                NavigationLink(destination: EndScene(myGame: _myGame), isActive: $isEnd){
                    EmptyView()
                }
                // Countdown
                if myGame.gameStatus == "Ready" {
                    if showCountdown {
                        Text("\(countNum)")
                            .font(.system(size: 80, weight: .bold))
                            .foregroundColor(.white)
                            .shadow(radius: 5)
                            .onAppear {
                                startCountdown()
                            }
                    }
                }
                
                // Car Image
                if let image = UIImage(named: myGame.carImageSelected) {
                    Image(uiImage: image)
                        .resizable()
                        .scaledToFit()
                        .frame(width: 150, height: 100)
                        .position(x: 120, y: 275)
                        .offset(x: carHorizonOffset, y: carVerticalOffset)
                } else {
                    Text("No image found")
                        .foregroundColor(.red)
                        .position(x: 120, y: 275)
                        .offset(x: carHorizonOffset, y: carVerticalOffset)
                }
                
                // Control Button
                Group {
                    // Up Button
                    Button(action: {
                        if carVerticalOffset > -100 && myGame.gameStatus == "Playing" {
                            withAnimation(.easeInOut(duration: 0.2)) {
                                carVerticalOffset -= 100  // Move up
                            }
                        }
                    }) {
                        Image(systemName: "arrow.up.circle.fill")
                            .font(.system(size: 60))
                            .foregroundColor(.white)
                    }
                    .position(x: 100, y: UIScreen.main.bounds.height - 50)
                    
                    // Down Button
                    Button(action: {
                        if carVerticalOffset < 100 && myGame.gameStatus == "Playing" {
                            withAnimation(.easeInOut(duration: 0.2)) {
                                carVerticalOffset += 100  // Move down
                            }
                        }
                    }) {
                        Image(systemName: "arrow.down.circle.fill")
                            .font(.system(size: 60))
                            .foregroundColor(.white)
                    }
                    .position(x: UIScreen.main.bounds.width - 100, y: UIScreen.main.bounds.height - 50)
                }
                .opacity(showCountdown ? 0 : 1) // Buttons appear after countdown
            }//end if state
        }//zstack
        .navigationBarBackButtonHidden(true)
    }
    
//    private func hideIntroText() {
//        Task { @MainActor in
//            try? await Task.sleep(for: .seconds(2))
//            withAnimation {
//                showIntroText = false
//                showCountdown = true
//            }
//        }
//    }
    
    private func moveBackground() async {
        withAnimation(.linear(duration: 15)) {
            bgOffset = -6950
            myGame.gameStatus = "Playing"
        }
        try? await Task.sleep(for:.seconds(15))
        myGame.gameStatus = "Finished"
        await moveCar()
    }
    
    private func moveCar() async {
        withAnimation(.linear(duration:2)) {
            carHorizonOffset = 800
        }
        try? await Task.sleep(for:.seconds(2))
        isEnd = true
    }
    
    private func startCountdown() {
        Task { @MainActor in
            try? await Task.sleep(for: .seconds(1))
            countNum = 2
            try? await Task.sleep(for: .seconds(1))
            countNum = 1
            try? await Task.sleep(for: .seconds(1))
            showCountdown = false
            await moveBackground()
        }
    }
}

struct GameView_Previews: PreviewProvider {
    static var previews: some View {
        GameView()
            .environmentObject(GameData())
    }
}
