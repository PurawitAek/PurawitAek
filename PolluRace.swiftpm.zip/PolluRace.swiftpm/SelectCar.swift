//
//  SwiftUIView.swift
//  PolluRace
//
//  Created by Purawit Lattiprasat on 18/2/2568 BE.
//

import SwiftUI


struct SelectCar: View{
    @EnvironmentObject var myGame: GameData
    @Environment(\.dismiss) var dismiss
    @State private var isConfirm: Bool = false
    let carlist = [
        (carName: "Toyada Prize 2004", carType: "Petrol Car", carSpeed: "120km/hr", carImage: "NormalCar", horsePower: "300HP"),
        (carName: "Speedo XM 2020", carType: "Petrol Car", carSpeed: "180km/hr", carImage: "SportCar", horsePower: "600HP"),
        (carName: "Voltric S15 2023", carType: "Electric Car", carSpeed: "120km/hr", carImage: "ElectricCar", horsePower: "200HP")
    ]
    var body: some View {
        NavigationStack {
            ZStack {
                Image("SelectPageBG")
                    .resizable()
                    .scaledToFill()
                    .ignoresSafeArea()
                // Car selection
                VStack {
                    HStack(spacing: 20) {
                        ForEach(carlist, id: \.carName) { car in
                            CarView(carName: car.carName, carType: car.carType, carSpeed: car.carSpeed, carImage: car.carImage, horsePower: car.horsePower)
                        }
                    }
                    .padding(.top)
                    NavigationLink(destination: GameView(),isActive: $isConfirm) {
                        EmptyView()
                    }
                    // confirmation text and button
                    HStack {
                        TextField("Select Car", text: $myGame.carNameSelected)
                            .disabled(true)
                            .frame(width: 300, height: 20)
                            .padding()
                            .background(Color.white)
                            .cornerRadius(10)
                        
                        Button(action: {
                            myGame.gameStatus = "Waiting"
                            isConfirm = true
                        }) {
                            Image(systemName: "checkmark")
                                .foregroundColor(.white)
                                .padding()
                                .background(Color.green)
                                .cornerRadius(10)
                        }
                    }// end Hstack
                    .padding(.top,20)
                }// end Vstack
                .padding(.top,50)
                .navigationBarBackButtonHidden(true)
                // Back Button
                VStack {
                    HStack {
                        Button(action: {
                            myGame.gameStatus = "Main"
                            dismiss()
                        }) {
                            Image(systemName: "chevron.left")
                                .frame(width: 20, height: 20)
                                .font(.title2)
                                .padding()
                                .background(Color.gray.opacity(0.8))
                                .foregroundColor(.white)
                                .clipShape(Circle())
                        }
                        .padding(.leading, 20)
                        .padding(.top, 20)
                        
                        Spacer()
                    }
                    Spacer()
                }
            }
            
            
            
        }
    }
    
}
struct SelectCar_Previews: PreviewProvider {
    static var previews: some View {
        SelectCar()
    }
}
